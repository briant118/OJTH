/** Records page — calculate.html (show all sessions; add/edit/delete) */

let ojtRecordEditorModal = null;
let ojtRecordViewModal = null;

function ojtAskDeleteConfirm(message) {
  const modalEl = $("deleteConfirmModal");
  const bodyEl = $("deleteConfirmBody");
  const okBtn = $("btnDeleteConfirmRecord");
  const titleEl = $("deleteConfirmTitle");

  if (!modalEl || !bodyEl || !okBtn || !titleEl || typeof bootstrap === "undefined") {
    const ok = confirm(message);
    return Promise.resolve(ok);
  }

  bodyEl.textContent = message;

  const instance = bootstrap.Modal.getOrCreateInstance(modalEl);
  return new Promise((resolve) => {
    let decided = false;

    const onOk = () => {
      decided = true;
      instance.hide();
    };

    okBtn.addEventListener("click", onOk, { once: true });
    modalEl.addEventListener(
      "hidden.bs.modal",
      () => {
        resolve(decided);
      },
      { once: true }
    );

    instance.show();
  });
}

function ojtShowRecordEditor() {
  const el = $("recordEditorCard");
  if (!el) return;
  el.classList.remove("d-none");
}

function ojtHideRecordEditor() {
  const el = $("recordEditorCard");
  if (!el) return;
  el.classList.add("d-none");
}

function ojtShowRecordView(row) {
  if (!row) return;
  if ($("viewDate")) $("viewDate").textContent = row.date || "—";
  if ($("viewTimeIn")) $("viewTimeIn").textContent = row.timeIn || "—";
  if ($("viewTimeOut")) $("viewTimeOut").textContent = row.timeOut || "—";
  if ($("viewStatus")) $("viewStatus").textContent = ojtEntryIsOpen(row) ? "Open" : "Done";
  const h = row.hours ?? ojtComputeHoursBetween(row.timeIn, row.timeOut);
  if ($("viewHours")) {
    if (ojtEntryIsOpen(row)) {
      $("viewHours").textContent = "—";
    } else {
      const v = ojtFormatHours(h);
      $("viewHours").innerHTML = `<span class="ojt-hours-val">${v}</span>`;
    }
  }

  const el = $("recordViewModal");
  if (!el || typeof bootstrap === "undefined") return;
  ojtRecordViewModal = ojtRecordViewModal || bootstrap.Modal.getOrCreateInstance(el);
  ojtRecordViewModal.show();
}

function ojtNormalizeRecordTime(raw) {
  const s = String(raw || "").trim();
  if (!s) return "";

  // Accept compact digits: "8", "08", "800", "0830", "1730".
  const digitsOnly = s.replace(/\D/g, "");
  if (/^\d{1,4}$/.test(digitsOnly) && digitsOnly === s) {
    if (digitsOnly.length <= 2) {
      const h = Number(digitsOnly);
      if (Number.isNaN(h) || h < 0 || h > 23) return null;
      return `${String(h).padStart(2, "0")}:00`;
    }
    if (digitsOnly.length === 3) {
      const h = Number(digitsOnly.slice(0, 1));
      const m = Number(digitsOnly.slice(1));
      if (h < 0 || h > 23 || m < 0 || m > 59) return null;
      return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
    }
    const h = Number(digitsOnly.slice(0, 2));
    const m = Number(digitsOnly.slice(2));
    if (h < 0 || h > 23 || m < 0 || m > 59) return null;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  }

  // Accept strict HH:MM.
  const m = s.match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return null;
  let hh = Number(m[1]);
  const mm = Number(m[2]);

  if (Number.isNaN(hh) || Number.isNaN(mm) || mm < 0 || mm > 59) return null;
  if (hh < 0 || hh > 23) {
    return null;
  }

  return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
}

function ojtMaskTimeTyping(inputId) {
  const el = $(inputId);
  if (!el) return;
  const digits = String(el.value || "").replace(/\D/g, "").slice(0, 4);
  if (digits.length === 0) {
    el.value = "";
  } else if (digits.length <= 2) {
    el.value = `${digits}:`;
  } else {
    el.value = `${digits.slice(0, 2)}:${digits.slice(2)}`;
  }
}

function ojtFormatTimeInputValue(inputId) {
  const el = $(inputId);
  if (!el) return;
  const raw = String(el.value || "").trim();
  if (!raw) return;
  const normalized = ojtNormalizeRecordTime(raw);
  if (normalized) el.value = normalized;
}

function ojtResetRecordForm() {
  if ($("recordId")) $("recordId").value = "";
  if ($("recordDate")) $("recordDate").value = ojtTodayDateString();
  if ($("recordTimeIn")) $("recordTimeIn").value = "";
  if ($("recordTimeOut")) $("recordTimeOut").value = "";
  if ($("recordFormMode")) $("recordFormMode").textContent = "Adding new record";
}

function ojtLoadRecordIntoForm(row) {
  if (!row) return;
  if ($("recordId")) $("recordId").value = row.id || "";
  if ($("recordDate")) $("recordDate").value = row.date || "";
  if ($("recordTimeIn")) $("recordTimeIn").value = row.timeIn || "";
  if ($("recordTimeOut")) $("recordTimeOut").value = row.timeOut || "";
  if ($("recordFormMode")) $("recordFormMode").textContent = "Editing selected record";
}

function ojtSyncHeaderActionStates() {
  const selectedId = $("recordId")?.value?.trim() || "";
  const editBtn = $("btnEditRecordTop");
  const delBtn = $("btnDeleteRecordTop");
  if (editBtn) editBtn.disabled = !selectedId;
  if (delBtn) delBtn.disabled = !selectedId;
}

function ojtRenderRecordsTable() {
  const tbody = $("resultsTableBody");
  const meta = $("recordsMeta");
  const totalEl = $("recordsTotalHours");
  if (!tbody) return;

  const all = ojtLoadEntries();
  all.sort((a, b) => {
    const c = ojtCompareDateStr(b.date, a.date);
    if (c !== 0) return c;
    return String(b.timeIn || "").localeCompare(String(a.timeIn || ""));
  });

  let totalH = 0;
  all.forEach((row) => {
    if (!row.timeOut) return;
    const h = row.hours ?? ojtComputeHoursBetween(row.timeIn, row.timeOut);
    if (h != null && !Number.isNaN(h)) totalH += h;
  });

  if (meta) meta.textContent = `${all.length} ${all.length === 1 ? "record" : "records"}`;
  if (totalEl) {
    totalEl.innerHTML = `<span class="ojt-hours-val">${ojtFormatHours(totalH)}</span>`;
  }

  if (all.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5" class="text-center text-secondary py-4">No records yet. Add your first session above.</td>
      </tr>`;
    return;
  }

  tbody.innerHTML = all
    .map((row) => {
      const open = ojtEntryIsOpen(row);
      const h = row.hours ?? ojtComputeHoursBetween(row.timeIn, row.timeOut);
      const esc = ojtEscapeHtml;
      const toutDisplay = row.timeOut ? esc(row.timeOut) : '<span class="text-warning">—</span>';
      const statusBadge = open
        ? '<span class="badge text-bg-warning text-dark">Open</span>'
        : '<span class="badge text-bg-success">Done</span>';
      return `
      <tr class="ojt-record-row" data-entry-id="${esc(row.id)}">
        <td>${esc(row.date)}</td>
        <td>${esc(row.timeIn)}</td>
        <td>${toutDisplay}</td>
        <td>${statusBadge}</td>
        <td class="text-end fw-semibold">${open ? "—" : `<span class="ojt-hours-val">${ojtFormatHours(h)}</span>`}</td>
      </tr>`;
    })
    .join("");
  ojtSyncHeaderActionStates();
}

function ojtSaveRecordFromForm() {
  const id = $("recordId")?.value?.trim() || "";
  const date = $("recordDate")?.value || "";
  const rawTimeIn = $("recordTimeIn")?.value || "";
  const rawTimeOut = $("recordTimeOut")?.value || "";
  const timeIn = ojtNormalizeRecordTime(rawTimeIn);
  const timeOut = ojtNormalizeRecordTime(rawTimeOut);

  if (!date) {
    alert("Choose a date.");
    return;
  }
  if (!rawTimeIn.trim()) {
    alert("Enter time in.");
    return;
  }
  if (!timeIn) {
    alert("Invalid time in. Use HH:MM (example: 08:00).");
    return;
  }
  if (rawTimeOut.trim() && !timeOut) {
    alert("Invalid time out. Use HH:MM (example: 17:00).");
    return;
  }

  if ($("recordTimeIn")) $("recordTimeIn").value = timeIn;
  if ($("recordTimeOut")) $("recordTimeOut").value = timeOut || "";

  if (id) {
    // Existing row: always patch this same row (including time out when provided).
    const res = ojtPatchEntry(id, { date, timeIn, timeOut: timeOut || null });
    if (!res.ok) {
      alert(res.message || "Could not update record.");
      return;
    }
  } else {
    // New row: create complete session if time out exists, otherwise open session.
    if (timeOut) {
      const res = ojtSaveFullEntry({ date, timeIn, timeOut });
      if (!res.ok) {
        alert(res.message || "Could not save record.");
        return;
      }
    } else {
      const res = ojtAddOpenEntry(date, timeIn);
      if (!res.ok) {
        alert(res.message || "Could not save record.");
        return;
      }
    }
  }

  ojtResetRecordForm();
  ojtRenderRecordsTable();
  // UX: saving a record should close the editor.
  ojtHideRecordEditor();
}

function ojtWireRecordsPage() {
  const runDeleteCurrentRecord = async () => {
    const id = $("recordId")?.value?.trim() || "";
    if (!id) {
      alert("Click a record row first to delete.");
      return;
    }

    const ok = await ojtAskDeleteConfirm("Delete selected record?");
    if (!ok) return;

    ojtDeleteEntryById(id);
    ojtResetRecordForm();
    ojtRenderRecordsTable();
    ojtSyncHeaderActionStates();
  };

  $("btnSaveRecord")?.addEventListener("click", () => {
    ojtSaveRecordFromForm();
  });

  $("btnNewRecord")?.addEventListener("click", () => {
    ojtShowRecordEditor();
    ojtResetRecordForm();
  });
  $("btnAddRecordTop")?.addEventListener("click", () => {
    ojtShowRecordEditor();
    ojtResetRecordForm();
  });
  $("btnEditRecordTop")?.addEventListener("click", () => {
    const id = $("recordId")?.value?.trim() || "";
    if (!id) {
      alert("Click a record row first to edit.");
      return;
    }
    const row = ojtLoadEntries().find((r) => r.id === id);
    if (!row) return;
    ojtShowRecordEditor();
    ojtLoadRecordIntoForm(row);
  });
  $("btnDeleteRecordTop")?.addEventListener("click", () => {
    runDeleteCurrentRecord();
  });
  $("btnDeleteRecordForm")?.addEventListener("click", () => {
    runDeleteCurrentRecord();
  });
  $("btnExportRecordTop")?.addEventListener("click", () => {
    if (typeof ojtExportDtrPdf === "function") {
      ojtExportDtrPdf();
      return;
    }
    alert("PDF export is unavailable right now.");
  });
  $("btnCloseRecordEditor")?.addEventListener("click", () => {
    ojtHideRecordEditor();
  });
  $("btnViewEditRecord")?.addEventListener("click", () => {
    const id = $("recordId")?.value?.trim() || "";
    if (!id) return;
    const row = ojtLoadEntries().find((r) => r.id === id);
    if (!row) return;
    ojtRecordViewModal?.hide();
    ojtShowRecordEditor();
    ojtLoadRecordIntoForm(row);
  });
  $("btnViewDeleteRecord")?.addEventListener("click", () => {
    ojtRecordViewModal?.hide();
    runDeleteCurrentRecord();
  });

  // Make time typing easier: normalize common formats when leaving the field.
  ["recordTimeIn", "recordTimeOut"].forEach((id) => {
    $(id)?.addEventListener("input", () => ojtMaskTimeTyping(id));
    $(id)?.addEventListener("blur", () => ojtFormatTimeInputValue(id));
  });

  $("resultsTableBody")?.addEventListener("click", (e) => {
    const rowEl = e.target.closest(".ojt-record-row");
    if (!rowEl) return;
    const id = rowEl.getAttribute("data-entry-id");
    if (!id) return;
    const row = ojtLoadEntries().find((r) => r.id === id);
    if (!row) return;
    ojtLoadRecordIntoForm(row);
    ojtShowRecordView(row);
    ojtSyncHeaderActionStates();
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  startLiveClock();
  ojtWireRecordsPage();
  ojtResetRecordForm();
  ojtHideRecordEditor();
  await ojtSyncEntriesFromServer();
  ojtRenderRecordsTable();
  ojtSyncHeaderActionStates();
});
